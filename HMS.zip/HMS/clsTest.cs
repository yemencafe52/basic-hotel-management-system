﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace HMS
//{
//    class clsTest
//    {
//        static void Main()
//        {
//           // Event.Add(new Event("تشغيل النظام", DateTime.Now));
//           // //Utilities.TestDB();

//           // //Customer c1 = new Customer(5, "custommer5", CardType.Card1, "121AX2313", "");

//           // //bool res = Customer.Add(c1);

//           // //Room room1 = new Room(1);

//           // //Room.Update(room1);

//           // // Customer c1 = new Customer(1);


//           // //User user3 = new User(3, "support", "support");
//           // //bool res = User.Add(user3);



//           // //User user = new User(3);

//           // //bool res = User.Update(user);

//           // User.Login(new User(1));

//           // //  Room r = new Room(1);
//           // // Resevation rs = new Resevation(0, DateTime.Now, DateTime.Now, new Customer(1), r.Price * 2, "", User.ActiveUser, State.State2);

//           // Param.Read();

//           //// ReservationsManager.ChangeRoomState(r,rs);
//           // Event.Add(new Event("إيقاف تشغيل النظام", DateTime.Now));
//        }
//    }
//}
